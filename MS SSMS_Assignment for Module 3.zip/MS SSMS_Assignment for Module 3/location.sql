USE DW
DROP TABLE DW.dbo.LOCATION1
GO
 CREATE TABLE LOCATION1 (
 LocNo VARCHAR(8) NOT NULL,
 FacNo VARCHAR(8) NOT NULL,
 LocName VARCHAR(30) CONSTRAINT NotNull_LocName NOT NULL,
 CONSTRAINT PK_Location  PRIMARY KEY(Locno),
 CONSTRAINT FK_Location FOREIGN KEY(FacNo) REFERENCES Facility(FacNo)
 );
 GO

Insert into LOCATION1 (LOCNO,FACNO,LOCNAME) values ('L100','F100','Locker room');
Insert into LOCATION1 (LOCNO,FACNO,LOCNAME) values ('L101','F100','Plaza');
Insert into LOCATION1 (LOCNO,FACNO,LOCNAME) values ('L102','F100','Vehicle gate');
Insert into LOCATION1 (LOCNO,FACNO,LOCNAME) values ('L103','F101','Locker room');
Insert into LOCATION1 (LOCNO,FACNO,LOCNAME) values ('L104','F100','Ticket Booth');
Insert into LOCATION1 (LOCNO,FACNO,LOCNAME) values ('L105','F101','Gate');
Insert into LOCATION1 (LOCNO,FACNO,LOCNAME) values ('L106','F100','Pedestrian gate');