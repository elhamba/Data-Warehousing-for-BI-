USE DW;
CREATE TABLE Customer (
Custno Varchar(8) NOT NULL,
Custname Varchar(30) NOT NULL,
Address Varchar(50) NOT NULL,
Internal Char(1) NOT NULL,
Contact Varchar(35)	NOT NULL,
Phone Varchar(11)  NOT NULL,
City Varchar(30) NOT NULL,
State Varchar(2) NOT NULL,
Zip Varchar(10) NOT NULL,
CONSTRAINT PK_Customer PRIMARY KEY(Custno));

INSERT INTO Customer(Custno,Custname,Address,Internal,Contact,Phone,City,State,Zip) VALUES
('C100','Football','Box 352200','Y','Mary Manager','6857100','Boulder','CO','80309');
INSERT INTO Customer(Custno,Custname,Address,Internal,Contact,Phone,City,State,Zip) VALUES
('C101','Men''s Basketball','Box 352400','Y','Sally Supervisor','5431700','Boulder','CO','80309');
INSERT INTO Customer(Custno,Custname,Address,Internal,Contact,Phone,City,State,Zip) VALUES
('C103','Baseball','Box 352020','Y','Bill Baseball','5431234','Boulder','CO','80309');
INSERT INTO Customer(Custno,Custname,Address,Internal,Contact,Phone,City,State,Zip) VALUES
('C104','Women''s Softball','Box 351200','Y','Sue Softball','5434321','Boulder','CO','80309');
INSERT INTO Customer(Custno,Custname,Address,Internal,Contact,Phone,City,State,Zip) VALUES
('C105','High School Football','123 AnyStreet','N','Coach Bob','4441234','Louisville','CO','80027');

SELECT * FROM Customer 
