USE dw;
#1.	List the customer number, the name, the phone number, and the city of customers.
SELECT CUSTNO,CUSTNAME,PHONE,CITY FROM CUSTOMER;

#2.	List the customer number, the name, the phone number, and the city of customers who reside in Colorado (State is CO).
SELECT CUSTNO,CUSTNAME,PHONE,CITY FROM CUSTOMER
WHERE STATE='CO';

#3.	List all columns of the EventRequest table for events costing more than $4000. 
# Order the result by the event date (DateHeld).
SELECT * FROM eventrequest WHERE ESTCOST>4000
ORDER BY DATEHELD;

#4.	List the event number, the event date (DateHeld), and the estimated audience number with approved status and 
#audience greater than 9000 or with pending status and audience greater than 7000.
SELECT EVENTNO,DATEHELD,ESTAUDIENCE FROM EVENTREQUEST
WHERE (STATUS1='APPROVED' AND ESTAUDIENCE>9000) OR (STATUS1='PENDING' AND ESTAUDIENCE>7000);

#5.	List the event number, event date (DateHeld), customer number and customer name of events placed in 
#January 2013 by customers from Boulder.

SELECT EVENTNO,DATEHELD,EVENTREQUEST.CUSTNO,CUSTNAME,STATE
FROM eventrequest INNER JOIN CUSTOMER ON CUSTOMER.CUSTNO=EVENTREQUEST.CUSTNO
WHERE DATEHELD BETWEEN '2013-12-01' AND '2013-12-31' AND STATE='CO';

SELECT EVENTNO,DATEHELD,CUSTOMER.CUSTNO,CUSTNAME,STATE
FROM EVENTREQUEST,CUSTOMER WHERE CUSTOMER.CUSTNO=EVENTREQUEST.CUSTNO
AND DATEHELD BETWEEN '2013-12-01' AND '2013-12-31' AND STATE='CO';

#6.	List the average number of resources used (NumberFld) by plan number. Include only location number L100.
#SELECT PLANNO,AVG(NUMBERFLD) AS AVG_NumResources FROM EVENTPLANLINE
SELECT * FROM EVENTPLANLINE
WHERE LOCNO='L100'
GROUP BY PLANNO;


#7.	List the average number of resources used (NumberFld) by plan number. Only include location number L100. 
#Eliminate plans with less than two event lines containing location number L100.

SELECT PLANNO,AVG(NUMBERFLD) AS AVG_NumResources, COUNT(*) AS EventLineNumber FROM EVENTPLANLINE 
WHERE LOCNO='L100' 
GROUP BY PLANNO
HAVING EventLineNumber>1;

 