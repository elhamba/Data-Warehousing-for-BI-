use ordent;
#1.	List the order number, order date, customer number, customer name (first and last), employee number,
# and employee name (first and last) of January 2013 orders placed by Colorado customers.
select ordertbl.ordno,orddate,customer.custno,custfirstname,custlastname,
employee.empno,empfirstname,emplastname
from ordertbl inner join customer on ordertbl.custno=customer.custno
inner join employee on employee.empno=ordertbl.empno
where orddate between str_to_date('1,Jan,13','%d,%b,%y') and str_to_date('31,Jan,13','%d,%b,%y') 
and custstate='CO';

#2.	List the customer number, name (first and last), order number, order date, employee number, 
#employee name (first and last), product number, product name, and order cost (OrdLine.Qty * ProdPrice) 
#for products ordered on January 23, 2013, in which the order cost exceeds $150.

select customer.custno,custfirstname,custlastname,ordertbl.ordno,orddate,employee.empno,
empfirstname,emplastname,product.prodno,prodname,ordline.qty*prodprice as prodcost
from customer inner join ordertbl on customer.custno=ordertbl.custno
inner join employee on employee.empno=ordertbl.empno 
inner join ordline on ordline.ordno=ordertbl.ordno
inner join product on product.prodno=ordline.prodno
where orddate=str_to_date('23,Jan,13','%d,%b,%y') and ordline.qty*prodprice>150;


#3.	List the order number and total amount for orders placed on January 23, 2013. The total amount of 
#an order is the sum of the quantity times the product price of each product on the order.
select ordertbl.ordno,sum(ordline.qty*product.prodprice) as TotalAmountPerOrd
from ordertbl inner join ordline on ordertbl.ordno=ordline.ordno
inner join product on product.prodno=ordline.prodno
where orddate=str_to_date('23,Jan,13','%d,%b,%y')
group by ordertbl.ordno;

#4.	List the order number, order date, customer name (first and last), and total amount for orders 
#placed on January 23, 2013. The total amount of an order is the sum of the quantity times the product 
#price of each product on the order.

select ordertbl.ordno,orddate,custfirstname,custlastname,
sum(ordline.qty*product.prodprice) as TotalAmountPerOrd
from ordertbl inner join customer on ordertbl.custno=customer.custno
inner join  ordline on ordertbl.ordno=ordline.ordno
inner join product on product.prodno=ordline.prodno
where orddate=str_to_date('23,Jan,13','%d,%b,%y')
group by customer.custno,ordno;

#5.	Insert yourself as a new row in the Customer table.
#6.	Insert an imaginary friend as a new row in the Employee table.
#7.	Increase the price by 10 percent of products containing the words Ink Jet.
set SQL_SAFE_UPDATES=0;
update product
set prodprice=1.1*prodprice
where prodname like '%Ink Jet%';
set SQL_SAFE_UPDATES=1;

#8.	Delete the new row added to the Customer table.
