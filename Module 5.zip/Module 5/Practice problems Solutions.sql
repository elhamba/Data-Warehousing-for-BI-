USE DW;
#1.	List the event number, date held, customer number, customer name, facility number,
# and facility name of 2013 events placed by Boulder customers.

SELECT EVENTNO, DATEHELD, CUSTOMER.CUSTNO, CUSTNAME,FACILITY.FACNO,FACNAME
FROM EVENTREQUEST, CUSTOMER, FACILITY
WHERE
EVENTREQUEST.CUSTNO=CUSTOMER.CUSTNO AND
EVENTREQUEST.FACNO=FACILITY.FACNO AND
FACILITY.FACNAME='2013' AND CUSTOMER.STATE='Boulder';


#2.	List the customer number, customer name, event number, date held, facility number, facility name, 
#and estimated audience cost per person (EstCost / EstAudience) for events held on 2013, in which the 
#estimated cost per person is less than $0.2
SELECT CUSTOMER.CUSTNO,CUSTNAME,EVENTREQUEST.EVENTNO,DATEHELD,
FACILITY.FACNO,FACNAME,ESTCOST/ESTAUDIENCE AS EstCostPerPerson 
FROM CUSTOMER INNER JOIN EVENTREQUEST ON CUSTOMER.CUSTNO=EVENTREQUEST.CUSTNO
INNER JOIN FACILITY ON EVENTREQUEST.FACNO=FACILITY.FACNO
WHERE DATEHELD BETWEEN str_to_date('1,Jan,13','%d,%b,%y') AND str_to_date('31,Dec,13','%d,%b,%y') 
AND ESTCOST/ESTAUDIENCE<0.2;

#3.	List the customer number, customer name, and total estimated costs for Approved events. 
#The total amount of events is the sum of the estimated cost for each event. Group the results by 
#customer number and customer name.
SELECT Customer.CUSTNO,CUSTNAME,SUM(ESTCOST) TotalEstCost
FROM CUSTOMER INNER JOIN EVENTREQUEST ON CUSTOMER.CUSTNO=EVENTREQUEST.CUSTNO
WHERE STATUS1='Approved'
GROUP BY CUSTOMER.CUSTNO,CUSTNAME;

#4.	Insert yourself as a new row in the Customer table.
INSERT INTO Customer(Custno,Custname,Address,Internal,Contact,Phone,City,State,Zip) VALUES
('C106','Vollayball','Box 3552200','N','Elham Rainy','575 xxxxxx','Riverside','CA','92505');

#5.	Increase the rate by 10 percent of nurse resource in the resource table.
set sql_safe_updates=0;
update resourcetbl
set rate=1.1*rate
where resname='nurse';
SET SQL_SAFE_UPDATES = 1;

#6.	Delete the new row added to the Customer table.
delete from customer where custno='C106';