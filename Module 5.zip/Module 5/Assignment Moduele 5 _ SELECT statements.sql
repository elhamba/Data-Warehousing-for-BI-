use dw;
#1.	For event requests, list the event number, event date (eventrequest.dateheld),
# and count of the event plans.  Only include event requests in the result if the event 
# request has more than one related event plan with a work date in December 2013.

select eventrequest.eventno,eventrequest.dateheld,eventplan.workdate,count(*) as EventPlanNo
from eventrequest inner join eventplan on eventrequest.eventno=eventplan.eventno
group by eventrequest.eventno
having count(*) >1 and eventplan.workdate between  str_to_date('1,Dec,13','%d,%b,%y') and str_to_date('31,Dec,13','%d,%b,%y');

#2.	List the plan number, event number, work date, and activity of event plans meeting the following 
#two conditions: (1) the work date is in December 2013 and (2) the event is held in the “Basketball arena”.  Your query must not use the facility number (“F101”) of the basketball arena in the WHERE clause. Instead, you should use a condition on the FacName column for the value of “Basketball arena”.

select eventplan.planno,eventrequest.eventno,eventplan.workdate,activity
from eventplan inner join eventrequest on eventplan.eventno=eventrequest.eventno 
inner join facility on eventrequest.facno=facility.facno
where eventplan.workdate between  str_to_date('1,Dec,13','%d,%b,%y') and str_to_date('31,Dec,13','%d,%b,%y')
and facname='Basketball arena';

#3.	List the event number, event date, status, and estimated cost of events where there is an event 
#plan managed by Mary Manager and the event is held in the basketball arena in the period October 1 
#to December 31, 2013.  

select EventRequest.EventNo,DateHeld,Status1,EstCost
FROM EventRequest 
INNER JOIN EventPlan ON EventRequest.EventNo=EventPlan.EventNo
INNER JOIN Employee ON EventPlan.EmpNo=Employee.EmpNo
INNER JOIN Facility ON Facility.FacNo=EventRequest.FacNo
WHERE EmpName='Mary Manager' 
AND FacName='Basketball Arena'
AND DateHeld BETWEEN str_to_date('1,Oct,13','%d,%b,%y') and str_to_date('31,Dec,13','%d,%b,%y');


#4.	List the plan number, line number, resource name, number of resources (eventplanline.number),
# location name, time start, and time end where the event is held at the basketball arena,
# the event plan has activity of activity of “Operation”, and the event plan has a work date in 
# the period October 1 to December 31, 2013.  

SELECT EventPlanLine.PlanNo,EventPlanLine.LineNo, ResourceTbl.ResName,EventPlanLine.NumberFld,
	   LocName,TimeStart,TimeEnd
FROM EventPlanLine 
INNER JOIN EventPlan   ON EventPlanLine.PlanNo=EventPlan.PlanNo
INNER JOIN ResourceTbl ON EventPlanLine.ResNo=ResourceTbl.ResNo
INNER JOIN Location1   ON EventPlanLine.LocNo=Location1.LocNo
INNER JOIN Facility    ON Location1.FacNo=Facility.FacNo
WHERE FacName='Basketball arena' 
AND Activity='Operation'
AND WorkDate BETWEEN str_to_date('1,Oct,13','%d,%b,%y') and str_to_date('31,Dec,13','%d,%b,%y');

# Database Modification Problems
#1.	Insert a new row into the Facility table with facility name “Swimming Pool”.

Insert into FACILITY (FACNO,FACNAME) values ('F104','Swimming Pool');
SELECT * FROM Facility; 

#2.	Insert a new row in the Location table related to the Facility row in modification problem 1. 
#The new row should have “Door” for the location name.
Insert into LOCATION1 (LOCNO,FACNO,LOCNAME) values ('L107','F104','Door');
SELECT * FROM Location1;

#3.	Insert a new row in the Location table related to the Facility row in modification problem 1. 
#The new row should have “Locker Room” for the location name.
Insert into LOCATION1 (LOCNO,FACNO,LOCNAME) values ('L108','F104','Locker Room');
SELECT * FROM Location1;

# 4. Change the location name of “Door” to “Gate” for the row inserted in modification problem 2.
SET SQL_SAFE_UPDATES=0;
UPDATE  Location1 SET LocName='Gate' Where LocName='Door';
SET SQL_SAFE_UPDATES=1;
SELECT * FROM Location1;




#5.	Delete the row inserted in modification problem 3.
DELETE FROM Location1 WHERE LocNo='L108';
SELECT * FROM Location1;

 
 
 
 
 
 
 
 
 
 
 
